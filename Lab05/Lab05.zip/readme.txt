build:	g++ main.c -lglu32 -lglut32 -lopengl32 -o dinosaur.exe
run:	dinosaur.exe